"use strict";
// This file holds the main code for plugins. Code in this file has access to
// the *figma document* via the figma global object.
// You can access browser APIs in the <script> tag inside "ui.html" which has a
// full browser environment (See https://www.figma.com/plugin-docs/how-plugins-run).
// This plugin creates rectangles on the screen.
const nodes = [];
figma.currentPage.selection.forEach(node => {
    const rect = figma.createRectangle();
    const absoluteBoundingBox = node.absoluteBoundingBox;
    if (absoluteBoundingBox) {
        rect.x = absoluteBoundingBox.x;
        rect.y = absoluteBoundingBox.y;
        rect.resize(node.width, node.height);
        rect.fills = [{ type: 'SOLID', color: { r: 0.263, g: 0.627, b: 0.278 }, opacity: 0.2 }];
        rect.name = "Hotspot";
        figma.currentPage.appendChild(rect);
        nodes.push(rect);
    }
});
figma.currentPage.selection = nodes;
figma.viewport.scrollAndZoomIntoView(nodes);
// Make sure to close the plugin when you're done. Otherwise the plugin will
// keep running, which shows the cancel button at the bottom of the screen.
figma.closePlugin();
